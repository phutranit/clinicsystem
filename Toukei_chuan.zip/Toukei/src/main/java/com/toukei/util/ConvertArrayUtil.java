package com.toukei.util;

public class ConvertArrayUtil {
	public static int[] convertArray(String[] strings) {
		final int[] ints = new int[strings.length];
		for (int i = 0; i < strings.length; i++) {
			ints[i] = Integer.parseInt(strings[i]);
		}
		return ints;
	}
}
