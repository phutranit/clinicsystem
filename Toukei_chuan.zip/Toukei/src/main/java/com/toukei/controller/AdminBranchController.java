package com.toukei.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.toukei.model.bean.Branch;
import com.toukei.model.bean.Position;
import com.toukei.model.dao.BranchDAO;
import com.toukei.model.dao.PositionDAO;
import com.toukei.util.CheckArrayUtil;
import com.toukei.util.ConvertArrayUtil;

/**
 * Handles requests for the application branch.
 */
@Controller
public class AdminBranchController {

	@Autowired
	private BranchDAO branchDAO;
	@Autowired
	private PositionDAO positionDAO;

	/**
	 * Simply selects the branch view tiles to render by returning its name.
	 */
	@RequestMapping(value = "/branch", method = RequestMethod.GET)
	public String home(Model model, HttpSession session) {
		model.addAttribute("listBranch", branchDAO.getItems());
		model.addAttribute("listPosition", positionDAO.getItems());
		session.setAttribute("listBranch", branchDAO.getItems());
		session.setAttribute("listPosition", positionDAO.getItems());
		return "admin.branch.index";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/updateBranch", method = RequestMethod.POST)
	public String updateBranch(@RequestParam(value = "branchno", defaultValue = "") String[] arBranchNo,
			@RequestParam(value = "branchname", defaultValue = "") String[] arBranchName,
			@RequestParam(value = "positionno", defaultValue = "") String[] arPositionNo,
			@RequestParam(value = "positionname", defaultValue = "") String[] arPositionName, HttpSession session,
			RedirectAttributes ra) {
		
		ArrayList<Branch> listBr = new ArrayList<Branch>();
		ArrayList<Branch> listBranchUpdate = new ArrayList<Branch>();
		ArrayList<Branch> listBranchInsert = new ArrayList<Branch>();
		ArrayList<Branch> listBranchDelete = new ArrayList<Branch>();

		ArrayList<Position> listPos = new ArrayList<Position>();
		ArrayList<Position> listPositionUpdate = new ArrayList<Position>();
		ArrayList<Position> listPositionInsert = new ArrayList<Position>();
		ArrayList<Position> listPositionDelete = new ArrayList<Position>();

		HashSet<String> hashSetNoBranch = new HashSet<String>();
		HashSet<String> hashSetNoPosition = new HashSet<String>();

		HashSet<String> hashSetNameBranch = new HashSet<String>();
		HashSet<String> hashSetNamePosition = new HashSet<String>();
		// creat session branch
		session.setAttribute("arBranchNo", arBranchNo);
		session.setAttribute("arBranchName", arBranchName);
		// creat session position
		session.setAttribute("arPositionNo", arPositionNo);
		session.setAttribute("arPositionName", arPositionName);
		
		int noBranch = 0;
		int noPosition = 0;
		if (arBranchNo.length > 0) {
			// create list branch add and update
			for (int i = 0; i < arBranchNo.length; i++) {
				String n = arBranchNo[i];
				try {
					noBranch = Integer.parseInt(n);
				} catch (Exception e) {
					ra.addFlashAttribute("msg", "No branch : [ " + n + " ] must be an integer!");
					return "redirect:/branch?error=1";
				}
				String name = arBranchName[i];
				Branch br = new Branch(noBranch, name);
				listBr.add(br);
				hashSetNoBranch.add(n);
				hashSetNameBranch.add(name);
				///////
				if (branchDAO.checkNo(noBranch) != null) {
					listBranchUpdate.add(br);
				} else {
					if (branchDAO.checkNoByFlg(noBranch) != null) {
						ra.addFlashAttribute("msg", "No branch : [ " + noBranch + " ]  already exists!");
						return "redirect:/branch?error=1";
					}
					listBranchInsert.add(br);
				}
			}
			// // check no branch duplicate value
			if (hashSetNoBranch.size() != arBranchNo.length) {
				ra.addFlashAttribute("msg", "No branch is duplicate! Duplicate value : "
						+ CheckArrayUtil.findPopular(ConvertArrayUtil.convertArray(arBranchNo)));
				return "redirect:/branch?error=1";
			}
			if (hashSetNameBranch.size() != arBranchName.length) {
				ra.addFlashAttribute("msg",
						"Name branch is duplicate! Duplicate value : " + CheckArrayUtil.findPopular(arBranchName));
				return "redirect:/branch?error=1";
			}
		}
		if (arPositionNo.length > 0) {
			// create list position add and update
			for (int i = 0; i < arPositionNo.length; i++) {
				String n = arPositionNo[i];
				try {
					noPosition = Integer.parseInt(n);
				} catch (Exception e) {
					ra.addFlashAttribute("msg", "No Position : " + n + " must be an integer!");
					return "redirect:/branch?error=1";
				}
				String name = arPositionName[i];
				Position po = new Position(noPosition, name);
				listPos.add(po);
				hashSetNoPosition.add(n);
				hashSetNamePosition.add(name);
				if (positionDAO.checkNo(noPosition) != null) {
					listPositionUpdate.add(po);
				} else {
					if (positionDAO.checkNoByFlg(noPosition) != null) {
						ra.addFlashAttribute("msg", "No Position : [ " + noPosition + " ]  already exists!");
						return "redirect:/branch?error=1";
					}
					listPositionInsert.add(po);
				}
			}

			// check no postion duplicate value
			if (hashSetNoPosition.size() != arPositionNo.length) {
				ra.addFlashAttribute("msg", "No Position is duplicate! Duplicate value : "
						+ CheckArrayUtil.findPopular(ConvertArrayUtil.convertArray(arPositionNo)));
				return "redirect:/branch?error=1";
			}
			if (hashSetNamePosition.size() != arPositionName.length) {
				ra.addFlashAttribute("msg",
						"Name Position is duplicate! Duplicate value : " + CheckArrayUtil.findPopular(arPositionName));
				return "redirect:/branch?error=1";
			}
		}
		// list branch delete -> update flg = 1
		if (session.getAttribute("listBranch") != null) {
			List<Branch> listB = (List<Branch>) session.getAttribute("listBranch");
			for (Branch branch : listB) {
				if (branch.getFlg() != 0) {
					listBranchDelete.add(branch);
				}
			}
		}
		// list postion delete -> update flg = 1
		if (session.getAttribute("listPosition") != null) {
			List<Position> listP = (List<Position>) session.getAttribute("listPosition");
			for (Position position : listP) {
				if (position.getFlg() != 0) {
					listPositionDelete.add(position);
				}
			}
		}
		// update database
		try {
			branchDAO.update(listBranchUpdate, listBranchDelete, listBranchInsert);
			positionDAO.update(listPositionUpdate, listPositionDelete, listPositionInsert);
			
			session.removeAttribute("listBranch");
			session.removeAttribute("arBranchNo");
			session.removeAttribute("arBranchName");
			session.removeAttribute("listPosition");
			session.removeAttribute("arPositionNo");
			session.removeAttribute("arPositionName");
		} catch (Exception e) {
			ra.addFlashAttribute("msg", "Failed to over your update, please try again.");
			return "redirect:/branch";
		}

		ra.addFlashAttribute("msg", "Update Success!");
		return "redirect:/branch";
	}
}
