package com.toukei.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application staff.
 */
@Controller
public class AdminStaffListController {
	/**
	 * Simply selects the staff view to render by returning its staff.
	 */
	@RequestMapping(value = { "/staff_list" }, method = RequestMethod.GET)
	public String index(ModelMap model) {
		return "admin.staff_list.index";
	}
}
