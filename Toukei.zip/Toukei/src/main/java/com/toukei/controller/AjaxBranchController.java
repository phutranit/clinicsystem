package com.toukei.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.toukei.model.bean.Branch;

/**
 * Handles requests for the application branch.
 */
@Controller
public class AjaxBranchController {
	
	/**
	 * Simply selects the branch view tiles to render by returning its name.
	 */
	@SuppressWarnings({ "unchecked" })
	@RequestMapping(value = "/ajaxDelBranch", method = RequestMethod.POST)
	@ResponseBody
	public void delBranch(Model model, @RequestParam("aiBranch") int iBranch,HttpSession session) {
		if(session.getAttribute("listBranch") != null) {
			List<Branch> listBranch = (List<Branch>)session.getAttribute("listBranch");
			try {
				listBranch.get(iBranch).setFlg(1);
			}catch(Exception e) {
				
			}
		}
	}
}
