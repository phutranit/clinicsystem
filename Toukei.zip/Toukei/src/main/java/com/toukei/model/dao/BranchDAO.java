package com.toukei.model.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.toukei.model.bean.Branch;

@Repository
public class BranchDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Branch> getItems() {
		String sql ="SELECT ID, NO , NAME, CLINICID, FLG "
					+"FROM CLI_BRANCH "
					+"WHERE FLG = 0 "
					+"ORDER BY NO ASC ";
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<Branch>(Branch.class));
	}
	
	public Branch checkNo(int no) {
		String sql ="SELECT ID, NO , NAME, CLINICID, FLG "
				+"FROM CLI_BRANCH "
				+"WHERE FLG = 0 AND NO = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {no},new BeanPropertyRowMapper<Branch>(Branch.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	public Branch checkNoByFlg(int no) {
		String sql ="SELECT ID, NO , NAME, CLINICID, FLG "
				+"FROM CLI_BRANCH "
				+"WHERE FLG = 1 AND NO = ? ";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] {no},new BeanPropertyRowMapper<Branch>(Branch.class));
		}catch(Exception e) {
			return null;
		}
	}
	
	public void editName(List<Branch> listBranch) {
		String sql = "UPDATE CLI_BRANCH SET NAME = ? WHERE NO = ? ";
		for (Branch branch : listBranch) {
			jdbcTemplate.update(sql,new Object[] {branch.getName(),branch.getNo()});
		}
	}
	
	public void editFlg(List<Branch> listBranch) {
		String sql = "UPDATE CLI_BRANCH SET FLG = ? WHERE ID = ? ";
		for (Branch branch : listBranch) {
			jdbcTemplate.update(sql,new Object[] {branch.getFlg(),branch.getId()});
		}
	}
	
	public void addItem(List<Branch> listBranch) {
		String sql = "INSERT INTO CLI_BRANCH(NAME,NO) VALUES(?,?) ";
		for (Branch branch : listBranch) {
			jdbcTemplate.update(sql,new Object[] {branch.getName(),branch.getNo()});
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
