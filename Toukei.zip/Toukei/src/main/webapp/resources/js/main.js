/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


	$(function () {
		var href = location.href;
		$('.nav a').each(function (e) {
			if (href.indexOf($(this).attr('href')) > 0) {
				$(this).parent().addClass('active');
			}
		});
	});

$(document).ready(function(){
	$("#add").click(function (e) {
		 //Append a new row of code to the "#items" div
		 $("#items1").append('<table class="table home-table"><td><div class="border"><input name="branchno" type="text" value="" /><span><i class="fa fa-chevron-right"></i></span></div></td><td><div class="border"><input name="branchname" type="text" value="" /></div></td><td><button class="delete"><i class="fa fa-trash-o"></i></button></td></table>');
		 });
	$("#add-2").click(function (e) {
		 //Append a new row of code to the "#items" div
		 $("#items2").append('<table class="table home-table"><td><div class="border"><input name="positionno" type="text" value=""/><span><i class="fa fa-chevron-right"></i></span></div></td><td><div class="border"><input name="positionname" type="text" value=""/></div></td><td><button class="delete"><i class="fa fa-trash-o"></i></button></td></table>');
		 });
	$("body").on("click", ".delete", function (e) {
		 $(this).closest('tr').remove()
	});
});
